﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ContractClaimSystem
{
    /// <summary>
    /// Interaction logic for ViewClaim.xaml
    /// </summary>
    public partial class ViewClaim : Window
    {
        private string Firstname { get; set; }

        public ViewClaim(string firstname)
        {
            InitializeComponent();
            Firstname = firstname; // Correctly assign the parameter to the property
            LoadTotalClaims();
        }

        private void LoadTotalClaims()
        {
            // Accessing the claims from InputProcess class
            var loadTotalClaims = InputProcess.Claims.Where(c => c.FirstName == Firstname).ToList();
            ClaimsTotalDataGrid.ItemsSource = loadTotalClaims;

            if (!loadTotalClaims.Any())
            {
                MessageBox.Show("Claim was not approved", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
