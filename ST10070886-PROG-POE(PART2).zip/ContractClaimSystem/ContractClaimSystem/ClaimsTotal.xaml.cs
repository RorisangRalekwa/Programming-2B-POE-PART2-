﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ContractClaimSystem
{
    /// <summary>
    /// Interaction logic for ClaimsTotal.xaml
    /// </summary>
    public partial class ClaimsTotal : Window
    {

        public ClaimsTotal()
        {
            InitializeComponent();
            LoadClaims();  // Load claims when the window is initialized
        }

        private void LoadClaims()
        {
            ClaimsDataGrid.ItemsSource = InputProcess.Claims.ToList();  // Load all claims
        }

        

        private void Declinebutton_Click(object sender, RoutedEventArgs e)
        {
            var claim = (Claim)ClaimsDataGrid.SelectedItem;
            if (claim != null)
            {
                claim.Status = "Declined";
                MessageBox.Show("Amount due has been declined", "Status Update", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadClaims();
            }
        }

        private void Approvebutton_Click(object sender, RoutedEventArgs e)
        {
            var claim = (Claim)ClaimsDataGrid.SelectedItem;
            if (claim != null)
            {
                claim.Status = "Approved";
                MessageBox.Show("Amount due has been approved", "Status Update", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadClaims();
            }
        }
    }
}
