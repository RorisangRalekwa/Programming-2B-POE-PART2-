﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ContractClaimSystem
{
    /// <summary>
    /// Interaction logic for InputProcess.xaml
    /// </summary>
    public partial class InputProcess : Window
    {

        public static List<Claim> Claims = new List<Claim>();

        public InputProcess()
        {
            InitializeComponent();
        }

        private void Enterbutton_Click(object sender, RoutedEventArgs e)
        {
            string firstName = FirstNametextBox.Text;
            string lastName = LastNametextBox.Text;
            string staffNumber = StaffNumbertextBox.Text;
            string hourlyRate = HourlyRatetextBox.Text;
            string hoursWorked = HoursWorkedtextBox.Text;
            string departmentModule = DepartmentModuletextBox.Text;

            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(hourlyRate) || string.IsNullOrEmpty(hoursWorked))
            {
                MessageBox.Show("Please enter all the information", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Claim newClaim = new Claim
            {
                FirstName = firstName,
                LastName = lastName,
                StaffNumber = staffNumber,
                HourlyRate = hourlyRate,
                HoursWorked = hoursWorked,
                DepartmentModule = departmentModule,
                Status = "Pending"
            };

            Claims.Add(newClaim);
            MessageBox.Show("Claim has been successfully added", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

            // Clear text fields after adding
            FirstNametextBox.Clear();
            LastNametextBox.Clear();
            StaffNumbertextBox.Clear();
            HourlyRatetextBox.Clear();
            HoursWorkedtextBox.Clear();
            DepartmentModuletextBox.Clear();
        }

        private void Cancelbutton_Click(object sender, RoutedEventArgs e)
        {
            // Clear all the text fields
            FirstNametextBox.Clear();
            LastNametextBox.Clear();
            StaffNumbertextBox.Clear();
            HourlyRatetextBox.Clear();
            HoursWorkedtextBox.Clear();
            DepartmentModuletextBox.Clear();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void TotalClaimButton_Click(object sender, RoutedEventArgs e)
        {
            ClaimsTotal claimsTotalWindow = new ClaimsTotal();
            claimsTotalWindow.Show();
        }

        private void Viewbutton_Click(object sender, RoutedEventArgs e)
        {
            String Firstname = FirstNametextBox.Text;

            if (string.IsNullOrEmpty(Firstname))
            {
                MessageBox.Show("Please eneter your name to view total amount due", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }
    }       
}
