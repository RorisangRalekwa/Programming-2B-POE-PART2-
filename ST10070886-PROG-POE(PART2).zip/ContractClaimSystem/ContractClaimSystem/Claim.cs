﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContractClaimSystem
{
    public class Claim
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string StaffNumber { get; set; }
        public string HourlyRate { get; set; }
        public string HoursWorked { get; set; }
        public string DepartmentModule { get; set; }
        public string Upload { get; set; }
        public string Status { get; set; }

        public string TotalAmount
        {
            get
            {
                if (decimal.TryParse(HoursWorked, out var hours) && decimal.TryParse(HourlyRate, out var rate))
                {
                    return (hours * rate).ToString("C");
                }
                return "Invalid";
            }
        }
    }
}
